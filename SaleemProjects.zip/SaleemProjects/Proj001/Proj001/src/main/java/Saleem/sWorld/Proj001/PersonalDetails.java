package Saleem.sWorld.Proj001;

import javax.persistence.Entity;

@Entity
public class PersonalDetails 
{
	private String name;
	private int age;
	private int aadharNo;
	private int Eid;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(int aadharNo) {
		this.aadharNo = aadharNo;
	}
	public int getEid() {
		return Eid;
	}
	public void setEid(int eid) {
		Eid = eid;
	}
	
	@Override
	public String toString() {
		return "PersonalDetails [name=" + name + ", age=" + age + ", aadharNo=" + aadharNo + ", Eid=" + Eid + "]";
	}
	
	

}
