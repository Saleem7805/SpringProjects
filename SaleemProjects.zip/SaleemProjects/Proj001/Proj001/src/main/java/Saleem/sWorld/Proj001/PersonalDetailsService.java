package Saleem.sWorld.Proj001;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonalDetailsService 
{
	@Autowired
	PersonalDetailsDao pdd;
	
	public void addDetails(PersonalDetails p)
	{
		pdd.save(p);
	}

}
