package Saleem.sWorld.Proj001;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonalDetailsDao extends JpaRepository<PersonalDetails, Integer>
{
   
}
