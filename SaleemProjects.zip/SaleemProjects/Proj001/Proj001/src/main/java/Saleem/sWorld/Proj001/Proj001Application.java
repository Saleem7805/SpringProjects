package Saleem.sWorld.Proj001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proj001Application 
 {

	public static void main(String[] args) 
	{
		SpringApplication.run(Proj001Application.class, args);
	}

}
