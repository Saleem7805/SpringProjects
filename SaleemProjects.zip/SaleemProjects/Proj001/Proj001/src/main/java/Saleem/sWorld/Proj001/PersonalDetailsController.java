package Saleem.sWorld.Proj001;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class PersonalDetailsController {
	
	@Autowired
	PersonalDetailsService pds;
	
	@RequestMapping("/")
	
		public String doCheck()
		{
			return "index.jsp";
		}
	@RequestMapping("/add")
	@ResponseBody
	public void doAdd(PersonalDetails p)
	{
		
     pds.addDetails(p);
		
	}

}
