package Saleem.sWorld.Proj001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proj001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
