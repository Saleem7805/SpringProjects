package com.validate;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/myLogin")
public class Login extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out=resp.getWriter();
		String email=req.getParameter("name1");
		String mypass=req.getParameter("pass1");
		if(email.equalsIgnoreCase("94saleem@gmail.com")&& mypass.equals("root"))
		{
			
			out.println("Success");
		}
		else
		{
			out.println("Fail");
		}
	}
	
	

}
