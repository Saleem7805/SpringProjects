package saleem.begningpro1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Begningpro1Application {

	public static void main(String[] args) {
		SpringApplication.run(Begningpro1Application.class, args);
	}

}
