package saleem.begningpro1;

public class Product {

}
