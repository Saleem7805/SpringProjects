package saleem.begningpro1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Begningpro1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
