package com.constructor.injection;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println( "Hello World!" );
        ApplicationContext c=new ClassPathXmlApplicationContext("constructorconfig.xml");
        
        Person p=(Person)c.getBean("person");
        System.out.println(p);
        
       

	}

}
