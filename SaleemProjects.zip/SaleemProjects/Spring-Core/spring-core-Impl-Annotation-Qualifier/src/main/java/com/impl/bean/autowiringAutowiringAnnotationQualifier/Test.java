package com.impl.bean.autowiringAutowiringAnnotationQualifier;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context=new ClassPathXmlApplicationContext("AnnotationQualifier.xml");
		
	
		Employees e = context.getBean(Employees.class);

		System.out.println(e);
		

	}

}
