package com.impl.bean.autowiringAutowiringAnnotationQualifier;

public class Addresses {
	
	private String street;
	private String city;
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	public Addresses() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Addresses(String street, String city) {
		super();
		this.street = street;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Addresses [street=" + street + ", city=" + city + "]";
	}
	
	
	

}
