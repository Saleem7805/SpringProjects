package com.impl.bean.autowiringAutowiringAnnotationQualifier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employees {
	
@Autowired
@Qualifier("addresses1")
	private Addresses addresses;

public Addresses getAddresses() {
	return addresses;
}

public void setAddresses(Addresses addresses) {
	this.addresses = addresses;
}

public Employees(Addresses addresses) {
	super();
	this.addresses = addresses;
}



public Employees() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Employees [addresses=" + addresses + "]";
}

	
	

}
