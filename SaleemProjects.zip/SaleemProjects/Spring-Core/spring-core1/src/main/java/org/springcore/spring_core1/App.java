package org.springcore.spring_core1;

import java.awt.im.InputContext;

import org.springframework.aop.framework.AopContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext c=new ClassPathXmlApplicationContext("config.xml");
        
        Student s1=(Student)c.getBean("student1");
        System.out.println(s1);
    }
}
