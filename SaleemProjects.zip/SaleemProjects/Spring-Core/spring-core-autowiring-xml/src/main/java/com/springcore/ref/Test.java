package com.springcore.ref;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println( "Hello World!" );
        ApplicationContext c=new ClassPathXmlApplicationContext("collectionconfig.xml");
        
        A e1=(A)c.getBean("aref");
        System.out.println(e1);

	}

}
