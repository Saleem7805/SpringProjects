package com.springcore.collections;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println( "Hello World!" );
        ApplicationContext c=new ClassPathXmlApplicationContext("collectionconfig.xml");
        
        Emp e1=(Emp)c.getBean("emp1");
        System.out.println(e1);

	}

}
