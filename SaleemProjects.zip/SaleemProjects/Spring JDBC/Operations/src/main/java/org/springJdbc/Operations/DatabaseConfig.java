package org.springJdbc.Operations;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springJdbc.Operations.EmployeeDao;


@Configuration
public class DatabaseConfig {

    @Bean(name = "edao")
    public EmployeeDao employeeDao(DataSource dataSource) {
        EmployeeDao employeeDao = new EmployeeDao();
        employeeDao.setJdbcTemplate(new JdbcTemplate(dataSource));
        return employeeDao;
    }

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/springjdbc");
        dataSource.setUsername("root");
        dataSource.setPassword("root");
        return dataSource;
    }
}

