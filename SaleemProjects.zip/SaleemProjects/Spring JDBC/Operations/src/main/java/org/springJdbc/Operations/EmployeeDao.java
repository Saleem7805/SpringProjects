package org.springJdbc.Operations;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDao {  
		private static JdbcTemplate jdbcTemplate;  
		  
		public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
		    this.jdbcTemplate = jdbcTemplate;  
		}  
		  
		public static int saveEmployee(Employee e){  
		    String query="insert into employee values('"+e.getId()+"','"+e.getName()+"','"+e.getSalary()+"')";  
		    return jdbcTemplate.update(query);  
		}  
		
		public int updateEmployee(int id, String name, int salary) {  
		    String query = "update employee set name='" + name + "', salary='" + salary + "' where id='" + id + "' ";  
		    return jdbcTemplate.update(query);  
		}

		public static int deleteEmployee(int id){  
		    String query="delete from employee where id='"+id+"' ";  
		    return jdbcTemplate.update(query);  
		} 
	}


