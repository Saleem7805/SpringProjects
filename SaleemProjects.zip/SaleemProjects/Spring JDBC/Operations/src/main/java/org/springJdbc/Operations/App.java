package org.springJdbc.Operations;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springJdbc.Operations.EmployeeDao;


 class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context = new AnnotationConfigApplicationContext(DatabaseConfig.class);
        EmployeeDao dao=(EmployeeDao)context.getBean("edao");  
        int status=dao.saveEmployee(new Employee(102,"Amit",35000));  
        int status1=dao.saveEmployee(new Employee(103,"Rahul",55000));  
        int status2=dao.saveEmployee(new Employee(104,"Krishna",45000));  
        System.out.println(status);  
        
        // COMMENTING DELETING CODE UNCOMMENT WHEN U WANT TO USE
     // Deleting an employee with ID 101
//        int deleteStatus = dao.deleteEmployee(102);
//        int deleteStatus1 = dao.deleteEmployee(103);
//        int deleteStatus2 = dao.deleteEmployee(104);
//        System.out.println("Delete Status: " + deleteStatus);

        // Updating an employee with ID 102
        int updateStatus = dao.updateEmployee(102,"Rahul",45000);
        System.out.println("Update Status: " + updateStatus);

    }
}
